   #if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

/**
 * @author ${USER} renyu
 * @time ${DATE} ${TIME}
 */
#if (${VISIBILITY} == "PUBLIC")public #end class ${NAME} #if (${INTERFACES} != "")extends ${INTERFACES} #end {
}
